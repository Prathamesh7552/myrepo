class expense:
    def __init__(self,name,amt,cat):
        self.name = name
        self.amount = amt
        self.category = cat