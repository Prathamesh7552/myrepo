from ex import expense


def main():
    print('Programm Is Working')
    expense_file_path = "expense.csv"

    expense_chk = check_expense()
    save_file(expense_chk,expense_file_path)
    sumerise_expense(expense_file_path)

def check_expense():
    expense_name = input("Where Did You Spend:")
    expense_amount = eval(input("How Much Have You Spend: "))
    expense_category = ['Food','Travel','Shopping','Work','Fun','Misc']

    while True:
        print("In Which Category Are You Spending")
        for i,category_name in enumerate(expense_category):
            print(f'{i+1}.{category_name}')

        value_range = f'[1 - {len(expense_category)}]'
        select_index = int(input(f"Tell Me The category: {value_range}: ")) -1

        if select_index in range(len(expense_category)):
            selected_category = expense_category[select_index]
            print(selected_category)

            new_expense = expense(name = expense_name,amt= expense_amount,cat= selected_category)
            return new_expense

        else:
            print('The category Is Incorrect')    



        break

    
def save_file(expense_chk:expense,expense_file_path):
    print(f'I want To save The Expense In a File:{expense_chk}to{expense_file_path}')
    # it will create the CSV file automatically
    with open(expense_file_path,'a',encoding='utf-8') as f:
        f.write(f"{expense_chk.name},{expense_chk.amount},{expense_chk.category}\n")
   

def sumerise_expense(expense_file_path):
    print("We Are Making a Summary")
    with open(expense_file_path,'r',encoding='utf-8') as f:
              lines = f.readlines()
              for i in lines:
                 # print(i)
                 expense_name,expense_amount,expense_category = i.strip().split(',')
                 print(f'{expense_name} {expense_amount} {expense_category}')


if __name__ == "__main__":
    main()